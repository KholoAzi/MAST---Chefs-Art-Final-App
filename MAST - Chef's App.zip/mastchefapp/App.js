import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './HomeScreen';
import AddMenuItemScreen from './AddMenuItemScreen';
import MainMenuScreen from './MainMenuScreen';
import FilterScreen from './FilterScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  const [menuItems, setMenuItems] = useState([]);

  const addDish = (newDish) => {
    setMenuItems((prevMenuItems) => [...prevMenuItems, newDish]);
  };

  const removeDish = (index) => {
    setMenuItems((prevMenuItems) => prevMenuItems.filter((_, i) => i !== index));
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        {}
        <Stack.Screen 
          name="Home" 
          options={{ title: 'Chef Menu' }}
        >
          {props => <HomeScreen {...props} menuItems={menuItems} />}
        </Stack.Screen>

        {}
        <Stack.Screen 
          name="AddDish" 
          options={{ title: 'Add Dish' }}
        >
          {props => <AddMenuItemScreen {...props} addDish={addDish} />}
        </Stack.Screen>

        {}
        <Stack.Screen 
          name="Filter" 
          options={{ title: 'Filter Dishes' }}
        >
          {props => <FilterScreen {...props} menuItems={menuItems} />}
        </Stack.Screen>

        {}
        <Stack.Screen 
          name="MainMenu" 
          options={{ title: 'Main Menu' }}
        >
          {props => <MainMenuScreen {...props} menuItems={menuItems} removeDish={removeDish} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}
