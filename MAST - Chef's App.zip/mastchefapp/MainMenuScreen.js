import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, Button } from 'react-native';

export default function MainMenuScreen({ route, menuItems, removeDish }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Main Menu</Text>
      <Text style={styles.subtitle}>Total Dishes: {menuItems.length}</Text>
      <ScrollView style={styles.scrollContainer}>
        {menuItems.map((dish, index) => (
          <View key={index} style={styles.dishContainer}>
            <Image source={{ uri: dish.imageUri }} style={styles.image} />
            <Text style={styles.dishName}>{dish.name}</Text>
            <Text style={styles.description}>{dish.description}</Text>
            <Text style={styles.price}>Price: ${dish.price.toFixed(2)}</Text>
            <Text style={styles.course}>Course: {dish.course}</Text>
            <Text style={styles.rating}>Rating: {dish.rating}★</Text>
            <Button
              title="Remove Dish"
              onPress={() => removeDish(index)}
              color="#B22222"
            />
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#D7C6A9', 
  },
  title: {
    fontSize: 24,
    marginBottom: 10,
    fontWeight: 'bold',
    alignSelf: 'center',
  },
  subtitle: {
    fontSize: 18,
    marginBottom: 20,
    alignSelf: 'center',
  },
  scrollContainer: {
    flex: 1,
  },
  dishContainer: {
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 5, 
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
  dishName: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  description: {
    fontSize: 16,
    marginVertical: 5,
    textAlign: 'center',
  },
  price: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  course: {
    fontSize: 16,
    fontStyle: 'italic',
  },
  rating: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});
